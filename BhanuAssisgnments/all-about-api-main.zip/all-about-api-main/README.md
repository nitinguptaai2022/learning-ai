# all-about-api


## Projects Tech Stack Info
* **Flask:**  `Micro Web Framework` for creating APIs in Python.


#### What does `Micro` mean?
`Micro` does not mean that your whole web application has to fit into a single Python file (although it certainly can), nor does it mean that Flask is lacking in functionality. The `Micro` in microframework means Flask aims to keep the core simple but extensible. 


#### What does `Micro` mean?
`Micro` does not mean that your whole web application has to fit into a single Python file (although it certainly can), nor does it mean that Flask is lacking in functionality. The `Micro` in microframework means Flask aims to keep the core simple but extensible. 

Flask won’t make many decisions for you, such as what database to use. Those decisions that it does make, such as what templating engine to use, are easy to change. Everything else is up to you, so that Flask can be everything you need and nothing you don’t.

[click here to view information source](https://flask.palletsprojects.com/en/2.1.x/foreword/#what-does-micro-mean)

## Documents


## Projects
