# Projects

All projects are developed using `Python` programming language - `Flask` for APIs

I have used `PyCharm` IDE for development however you use any IDE which support `Python` development, [click here to download PyCharm for windows](https://www.jetbrains.com/pycharm/download/#section=windows), recommended to download community edition if you are just doing `Python` development

For testing `APIs`, I have used `Postman` tool, [click here to download Postman for windows](https://www.postman.com/downloads/)

**List of Projects**
* Simple Flask App
* Minimal Flask App
